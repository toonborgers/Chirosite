<span class="menuItem"><a href="index.php?page=home">Home</a></span>
<br/>
<span class="menuItem"><a href="index.php?page=oc">Oudercomit&eacute;</a></span>
<br/>
<span class="menuItem"><a href="index.php?page=foto">Foto's</a></span>
<br/>
<span class="menuItem" id="jongens">Jongens</span>
<span id="spacerJ"><br/></span>
<div id="jongensmenu">	
	<span class="menuItemL2"><a href="index.php?page=jprog">Programma's</a></span>
	<br/>
	<span class="menuItemL2"><a href="index.php?page=jhuren">Huren</a></span>
	<br/>
	<span class="menuItemL2"><a href="index.php?page=jleiding">Leiding</a></span>
	<br/>
	<span class="menuItemL2"><a href="index.php?page=jkal">Kalender</a></span>
</div>
<span class="menuItem" id="meisjes">Meisjes</span>
<div id="meisjesmenu">
	<span class="menuItemL2">test</span>
</div>
