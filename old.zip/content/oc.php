<h2>Het oudercomit�</h2>
<p>
	Het oudercomit� is een groep vrijwilligers die zich inzet voor de jongens- en meisjeschiro.
	Ieder ouder die de chiro een warm hart toedraagt wordt uitgenodigd om lid te worden.
	Dit houdt in om enkele vergaderingen per jaar bij te wonen en actief te helpen waar nodig.
	Indien u geinteresseerd bent in deze werking, kan u voor meer inlichtingen contact opnemen met het oudercomit�. 
</p>

<p>
	<h3>
		Wat doen ze zoal?
	</h3>
	<ul>
		<li>Ondersteunen bij fuiven</li>
		<li>Kleine en grote herstellingen aan de lokalen</li>
		<li>Het meisjeskamp mee opbouwen en afbreken</li>
		<li>Helpen op de bezoekdag</li>
		<li>De chirofeesten organiseren</li>
		<li>Helpen op den bouw</li>
		<li>Mee waken over de lange termijnvisie van de chiro's</li>
		<li>...</li>
	</ul>
</p>
	
<p>
	Leden:
	<ul>
		<li>Bert Leysen: Voorzitter</li>
		<li>Peter Heyns: Secretaris</li>
		<li>Patrick Stessens: Penningmeester</li>
		<li>Karel Van Gorp</li>
		<li>Eric Smets</li>
		<li>Gert Blockx</li>
		<li>Paul Boonen</li>
		<li>Loes Kersemans</li>
		<li>Raymond Boonen</li>
		<li>Rob Guns</li>
	</ul>
</p>