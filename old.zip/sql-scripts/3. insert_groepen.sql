-- Jongens
insert into groep values (null, 'j', 'VeeBee', 'FF1493',0);
insert into groep values (null, 'j', 'Sloebers', '800080',1);
insert into groep values (null, 'j', 'Speelclub', 'FFFF00',2);
insert into groep values (null, 'j', 'Rakkers', '008000',3);
insert into groep values (null, 'j', 'Toppers', 'FF0000',4);
insert into groep values (null, 'j', 'Kerels', '0000FF',5);
insert into groep values (null, 'j', 'Aspiranten', 'FFA500',6);

-- Meisjes
insert into groep values (null, 'm', 'VeeBee', 'FF1493',0);
insert into groep values (null, 'm', 'Pinkels', '800080',1);
insert into groep values (null, 'm', 'Speelclub', 'FFFF00',2);
insert into groep values (null, 'm', 'Kwiks', '008000',3);
insert into groep values (null, 'm', 'Tippers', 'FF0000',4);
insert into groep values (null, 'm', 'Tiptiens', '0000FF',5);
insert into groep values (null, 'm', 'Aspis', 'FFA500',6);